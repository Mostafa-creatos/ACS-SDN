/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        atlas: {
          ink: "#3B3081",
          primary: "#51509D",
          violet: "#564EBD",
          teal: "#42CCB2",
          coral: "#E26C48",
          lavender: "#BAC0D8"
        },
        sidebar: {
          bg: "#251F4A",
          hover: "#332B63"
        },
        surface: {
          light: "#F8F9FC",
          card: "#FFFFFF"
        },
        ink: {
          muted: "#6B6B85"
        }
      },
      fontFamily: {
        display: ["Sora", "Manrope", "sans-serif"],
        sans: ["Inter", "sans-serif"]
      },
      boxShadow: {
        card: "0 1px 2px 0 rgba(59, 49, 129, 0.06), 0 1px 6px -1px rgba(59, 49, 129, 0.08)"
      },
      borderRadius: {
        card: "8px"
      }
    }
  },
  plugins: []
};
