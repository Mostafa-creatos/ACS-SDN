import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { FileDown, Loader2 } from "lucide-react";
import type { DiagnosticBundle } from "@/lib/types";
import { requestDiagnosticBundle } from "@/lib/api";

export function DiagnosticBundleButton({ switchId }: { switchId: string }) {
  const [bundle, setBundle] = useState<DiagnosticBundle | null>(null);

  const mutation = useMutation({
    mutationFn: () => requestDiagnosticBundle(switchId),
    onSuccess: (result) => setBundle(result)
  });

  if (bundle?.status === "ready" && bundle.downloadUrl) {
    return (
      <a href={bundle.downloadUrl} className="btn-secondary" download>
        <FileDown className="h-4 w-4" />
        Download Diagnostic Bundle
      </a>
    );
  }

  return (
    <button
      type="button"
      className="btn-secondary"
      disabled={mutation.isPending || bundle?.status === "pending"}
      onClick={() => mutation.mutate()}
    >
      {mutation.isPending || bundle?.status === "pending" ? (
        <>
          <Loader2 className="h-4 w-4 animate-spin" />
          Generating Bundle...
        </>
      ) : (
        <>
          <FileDown className="h-4 w-4" />
          Generate Diagnostic Bundle
        </>
      )}
    </button>
  );
}
