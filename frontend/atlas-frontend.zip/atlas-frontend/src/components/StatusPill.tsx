import clsx from "clsx";
import type { LifecycleState } from "@/lib/types";

const LIFECYCLE_CONFIG: Record<LifecycleState, { label: string; dot: string; bg: string; text: string }> = {
  DiscoveredRaw: { label: "Discovered", dot: "bg-atlas-lavender", bg: "bg-atlas-lavender/15", text: "text-slate-600" },
  CompliantActive: { label: "Compliant & Active", dot: "bg-atlas-teal", bg: "bg-atlas-teal/15", text: "text-emerald-800" },
  SteadyStateAuditing: { label: "Auditing", dot: "bg-atlas-violet", bg: "bg-atlas-violet/15", text: "text-violet-800" },
  ContinuousStreamIngestion: { label: "Streaming", dot: "bg-atlas-teal", bg: "bg-atlas-teal/15", text: "text-emerald-800" },
  ConfigurationDrifted: { label: "Drifted", dot: "bg-atlas-coral", bg: "bg-atlas-coral/15", text: "text-orange-800" }
};

export function LifecycleStatusPill({ state }: { state: LifecycleState }) {
  const cfg = LIFECYCLE_CONFIG[state];
  return (
    <span className={clsx("status-pill", cfg.bg, cfg.text)}>
      <span className={clsx("h-1.5 w-1.5 rounded-full", cfg.dot)} aria-hidden="true" />
      {cfg.label}
    </span>
  );
}

const SEVERITY_CONFIG: Record<string, { bg: string; text: string; dot: string }> = {
  Critical: { bg: "bg-atlas-coral/15", text: "text-orange-900", dot: "bg-atlas-coral" },
  High: { bg: "bg-amber-100", text: "text-amber-800", dot: "bg-amber-500" },
  Medium: { bg: "bg-slate-100", text: "text-slate-700", dot: "bg-slate-400" },
  Low: { bg: "bg-slate-100", text: "text-slate-500", dot: "bg-slate-300" }
};

export function SeverityPill({ severity }: { severity: "Critical" | "High" | "Medium" | "Low" }) {
  const cfg = SEVERITY_CONFIG[severity];
  return (
    <span className={clsx("status-pill", cfg.bg, cfg.text)}>
      <span className={clsx("h-1.5 w-1.5 rounded-full", cfg.dot)} aria-hidden="true" />
      {severity}
    </span>
  );
}
