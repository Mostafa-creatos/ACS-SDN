import clsx from "clsx";
import type { HardwareInventoryItem } from "@/lib/types";
import { HardwareHealthIcon } from "./HealthBadge";

export function HardwareHealthTab({ items }: { items: HardwareInventoryItem[] }) {
  if (items.length === 0) {
    return (
      <div className="atlas-card text-sm text-ink-muted">
        No hardware inventory has been collected for this switch yet.
      </div>
    );
  }

  const criticalCount = items.filter((i) => i.status === "critical").length;
  const warningCount = items.filter((i) => i.status === "warning").length;

  return (
    <div className="space-y-4">
      {(criticalCount > 0 || warningCount > 0) && (
        <div
          className={clsx(
            "atlas-card",
            criticalCount > 0 ? "border-atlas-coral/40 bg-atlas-coral/5" : "border-amber-300 bg-amber-50"
          )}
        >
          <p className={clsx("text-sm font-medium", criticalCount > 0 ? "text-orange-800" : "text-amber-800")}>
            {criticalCount > 0
              ? `${criticalCount} component${criticalCount > 1 ? "s" : ""} reporting a critical fault.`
              : `${warningCount} component${warningCount > 1 ? "s" : ""} reporting a warning.`}
          </p>
        </div>
      )}

      <div className="atlas-card">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-ink-muted border-b border-atlas-lavender/30">
              <th className="py-2 font-medium">Slot</th>
              <th className="py-2 font-medium">Type</th>
              <th className="py-2 font-medium">Status</th>
              <th className="py-2 font-medium">Detail</th>
            </tr>
          </thead>
          <tbody>
            {items.map((item) => (
              <tr key={item.slot} className="border-b border-atlas-lavender/15 last:border-0">
                <td className="py-2 font-medium">{item.slot}</td>
                <td className="py-2">{item.type}</td>
                <td className="py-2">
                  <span className="inline-flex items-center gap-1.5">
                    <HardwareHealthIcon status={item.status} />
                    <span className="capitalize">{item.status}</span>
                  </span>
                </td>
                <td className="py-2 text-ink-muted">{item.detail}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
