import clsx from "clsx";
import { Link2, Link2Off } from "lucide-react";
import type { VltDomain } from "@/lib/types";

function LinkStateBadge({ state, label }: { state: "up" | "down"; label: string }) {
  const isUp = state === "up";
  return (
    <div className="flex items-center gap-2">
      {isUp ? (
        <Link2 className="h-4 w-4 text-atlas-teal" />
      ) : (
        <Link2Off className="h-4 w-4 text-atlas-coral" />
      )}
      <span className="text-sm">
        {label}:{" "}
        <span className={clsx("font-medium", isUp ? "text-emerald-700" : "text-orange-700")}>
          {state.toUpperCase()}
        </span>
      </span>
    </div>
  );
}

export function FabricVltTab({ vlt }: { vlt: VltDomain | null }) {
  if (!vlt) {
    return (
      <div className="atlas-card text-sm text-ink-muted">
        This switch is not a member of a VLT domain. VLT pairing applies to leaf switches
        deployed in redundant pairs; standalone or spine switches in a routed-only role may not use it.
      </div>
    );
  }

  const isSplitBrainRisk = vlt.iclState === "down";

  return (
    <div className="space-y-4">
      {isSplitBrainRisk && (
        <div className="atlas-card border-atlas-coral/40 bg-atlas-coral/5">
          <p className="text-sm font-medium text-orange-800">
            Inter-Chassis Link is down. This is a split-brain risk -- avoid pushing further
            configuration changes to this VLT pair until the ICL is restored.
          </p>
        </div>
      )}

      <div className="atlas-card">
        <h3 className="text-base font-display font-semibold mb-3">VLT Domain {vlt.domainId}</h3>
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <p className="text-ink-muted mb-1">Peer switch</p>
            <p className="font-medium">{vlt.peerSwitchHostname}</p>
          </div>
          <div>
            <p className="text-ink-muted mb-1">Peer routing</p>
            <p className="font-medium">{vlt.peerRoutingEnabled ? "Enabled" : "Disabled"}</p>
          </div>
        </div>
        <div className="mt-4 flex flex-col gap-2">
          <LinkStateBadge state={vlt.peerLinkStatus} label="Peer link" />
          <LinkStateBadge state={vlt.iclState} label="ICL (inter-chassis link)" />
        </div>
      </div>

      <div className="atlas-card">
        <h3 className="text-base font-display font-semibold mb-3">VRRP Groups</h3>
        {vlt.vrrpGroups.length === 0 ? (
          <p className="text-sm text-ink-muted">No VRRP groups configured on this switch.</p>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-ink-muted border-b border-atlas-lavender/30">
                <th className="py-2 font-medium">Group ID</th>
                <th className="py-2 font-medium">Virtual IP</th>
                <th className="py-2 font-medium">State</th>
              </tr>
            </thead>
            <tbody>
              {vlt.vrrpGroups.map((g) => (
                <tr key={g.groupId} className="border-b border-atlas-lavender/15 last:border-0">
                  <td className="py-2">{g.groupId}</td>
                  <td className="py-2">{g.vip}</td>
                  <td className="py-2">
                    <span
                      className={clsx(
                        "status-pill",
                        g.state === "master" ? "bg-atlas-teal/15 text-emerald-800" : "bg-slate-100 text-slate-600"
                      )}
                    >
                      {g.state}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
