import clsx from "clsx";
import { CheckCircle2, AlertTriangle, XCircle, HelpCircle } from "lucide-react";
import type { HealthStatus } from "@/lib/types";

const CONFIG: Record<HealthStatus, { icon: typeof CheckCircle2; color: string; label: string }> = {
  ok: { icon: CheckCircle2, color: "text-atlas-teal", label: "Hardware OK" },
  warning: { icon: AlertTriangle, color: "text-amber-500", label: "Hardware Warning" },
  critical: { icon: XCircle, color: "text-atlas-coral", label: "Hardware Critical" },
  unknown: { icon: HelpCircle, color: "text-ink-muted", label: "Hardware Unknown" }
};

/**
 * Compact icon-only badge for dense contexts (e.g. the Switches list table),
 * where a full text label would add an unwanted extra column.
 */
export function HardwareHealthIcon({ status }: { status: HealthStatus }) {
  const cfg = CONFIG[status];
  const Icon = cfg.icon;
  return (
    <span title={cfg.label} aria-label={cfg.label}>
      <Icon className={clsx("h-4 w-4", cfg.color)} />
    </span>
  );
}

/** Full badge with label, used on the Overview tab and Hardware & Health tab header. */
export function HardwareHealthBadge({ status }: { status: HealthStatus }) {
  const cfg = CONFIG[status];
  const Icon = cfg.icon;
  return (
    <span className={clsx("inline-flex items-center gap-1.5 text-sm font-medium", cfg.color)}>
      <Icon className="h-4 w-4" />
      {cfg.label}
    </span>
  );
}
