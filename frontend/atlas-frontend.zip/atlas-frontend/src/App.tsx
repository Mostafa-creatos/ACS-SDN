import { Routes, Route, NavLink, Navigate } from "react-router-dom";
import { LayoutDashboard, Network, Share2, Globe2, ShieldCheck, ClipboardCheck } from "lucide-react";
import clsx from "clsx";
import SwitchesPage from "./pages/SwitchesPage";
import SwitchDetailPage from "./pages/SwitchDetailPage";
import DashboardPage from "./pages/DashboardPage";
import TopologyPage from "./pages/TopologyPage";
import IpamPage from "./pages/IpamPage";
import CompliancePage from "./pages/CompliancePage";
import ApprovalsPage from "./pages/ApprovalsPage";

const NAV_ITEMS = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/switches", label: "Switches", icon: Network },
  { to: "/topology", label: "Topology", icon: Share2 },
  { to: "/ipam", label: "IP Management", icon: Globe2 },
  { to: "/compliance", label: "Compliance", icon: ShieldCheck },
  { to: "/approvals", label: "Pending Approvals", icon: ClipboardCheck }
];

export default function App() {
  return (
    <div className="flex h-screen overflow-hidden">
      <aside className="w-56 bg-sidebar-bg flex flex-col flex-shrink-0">
        <div className="h-16 flex items-center px-5">
          <div className="h-8 w-8 rounded-full bg-atlas-teal flex items-center justify-center text-white font-display font-bold text-sm">
            A
          </div>
        </div>
        <nav className="flex-1 px-2 space-y-1">
          {NAV_ITEMS.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                clsx(
                  "flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors border-l-2",
                  isActive
                    ? "bg-sidebar-hover text-white border-atlas-teal"
                    : "text-slate-300 border-transparent hover:bg-sidebar-hover hover:text-white"
                )
              }
            >
              <item.icon className="h-4 w-4" />
              {item.label}
            </NavLink>
          ))}
        </nav>
      </aside>

      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="h-16 bg-white border-b border-atlas-lavender/30 flex items-center justify-between px-6 flex-shrink-0">
          <span className="font-display font-semibold text-atlas-ink text-lg">Atlas Cloud SDN Controller</span>
          <div className="flex items-center gap-4">
            <span className="text-sm text-ink-muted">Tenant: Demo MSP</span>
            <div className="h-8 w-8 rounded-full bg-atlas-primary text-white flex items-center justify-center text-xs font-medium">
              PA
            </div>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto bg-surface-light">
          <Routes>
            <Route path="/" element={<Navigate to="/dashboard" replace />} />
            <Route path="/dashboard" element={<DashboardPage />} />
            <Route path="/switches" element={<SwitchesPage />} />
            <Route path="/switches/:id" element={<SwitchDetailPage />} />
            <Route path="/topology" element={<TopologyPage />} />
            <Route path="/ipam" element={<IpamPage />} />
            <Route path="/compliance" element={<CompliancePage />} />
            <Route path="/approvals" element={<ApprovalsPage />} />
          </Routes>
        </main>
      </div>
    </div>
  );
}
