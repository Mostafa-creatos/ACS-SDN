export type LifecycleState =
  | "DiscoveredRaw"
  | "CompliantActive"
  | "SteadyStateAuditing"
  | "ContinuousStreamIngestion"
  | "ConfigurationDrifted";

export type Role = "platform_admin" | "tenant_admin" | "operator" | "readonly";
export type HealthStatus = "ok" | "warning" | "critical" | "unknown";

export interface User {
  id: string;
  email: string;
  role: Role;
  tenantId: string;
}

export interface Tenant {
  id: string;
  name: string;
}

export interface Switch {
  id: string;
  hostname: string;
  managementIp: string;
  vendor: string;
  osVersion: string;
  macAddress: string;
  serialNumber: string;
  lifecycleState: LifecycleState;
  role: "leaf" | "spine";
  lastSeenAt: string;
  // Overview tab extensions
  switchOperatingMode: "Full Switch" | "Smart Fabric";
  switchingMode: "cut-through" | "store-and-forward";
  bootImage: string;
  licenseStatus: "active" | "expired" | "unlicensed";
  uptime: string;
  // Hardware health rollup (drives the badge in list + overview)
  hardwareHealth: HealthStatus;
}

export interface InterfacePort {
  id: string;
  name: string;
  status: "up" | "down" | "admin-down";
  speed: string;
  vlan: number | null;
  description: string;
  switchportMode: "access" | "trunk" | "none";
  portChannelId: string | null;
  lacpState: "active" | "passive" | "none";
  stormControlEnabled: boolean;
  errdisableReason: string | null;
}

export interface ConfigSnapshot {
  id: string;
  takenAt: string;
  isBaseline: boolean;
  rawConfig: string;
}

export interface TopologyNode {
  id: string;
  hostname: string;
  lifecycleState: LifecycleState;
  role: "leaf" | "spine";
  vltDomainId: string | null;
}

export interface TopologyEdge {
  id: string;
  source: string;
  target: string;
  protocol: "lldp" | "vlt-icl";
  localInterface: string;
  remoteInterface: string;
}

export interface TopologyGraph {
  nodes: TopologyNode[];
  edges: TopologyEdge[];
}

export interface VltDomain {
  id: string;
  domainId: number;
  switchId: string;
  peerSwitchId: string;
  peerSwitchHostname: string;
  peerLinkStatus: "up" | "down";
  iclState: "up" | "down";
  peerRoutingEnabled: boolean;
  vrrpGroups: { groupId: number; vip: string; state: "master" | "backup" }[];
}

export interface HardwareInventoryItem {
  slot: string;
  type: "PSU" | "Fan" | "Supervisor" | "Line Card";
  status: HealthStatus;
  detail: string;
}

export interface SubnetSummary {
  id: string;
  cidr: string;
  vrf: string;
  total: number;
  used: number;
  available: number;
  utilizationPct: number;
}

export interface IpSearchResult {
  ipAddress: string;
  switchHostname: string;
  interfaceName: string;
  vlan: number | null;
  vrf: string;
  lastSeenAt: string;
}

export interface ComplianceFinding {
  id: string;
  switchHostname: string;
  vector: "NTP" | "DNS" | "AAA" | "VLT_PEER_LINK" | "ERRDISABLE" | "HARDWARE" | "TELNET_ENABLED";
  expected: string;
  actual: string;
  severity: "Critical" | "High" | "Medium" | "Low";
  status: "open" | "resolved";
  remediation: string;
}

export interface DashboardSummary {
  totalSwitches: number;
  compliantActive: number;
  configurationDrifted: number;
  pendingApprovals: number;
  lifecycleDistribution: { state: LifecycleState; count: number }[];
  complianceTrend: { date: string; score: number }[];
}

export interface PendingApproval {
  id: string;
  tenantName: string;
  summary: string;
  targetRole: "leaf" | "spine";
  blastRadius: number;
  diff: string;
  requestedAt: string;
}

export interface DiagnosticBundle {
  id: string;
  switchId: string;
  status: "pending" | "ready" | "failed";
  requestedAt: string;
  downloadUrl: string | null;
}

