import type {
  Switch,
  InterfacePort,
  ConfigSnapshot,
  TopologyGraph,
  SubnetSummary,
  ComplianceFinding,
  DashboardSummary,
  PendingApproval,
  VltDomain,
  HardwareInventoryItem,
  DiagnosticBundle
} from "./types";

export const MOCK_SWITCHES: Switch[] = [
  {
    id: "sw-1",
    hostname: "leaf-01.demo",
    managementIp: "10.5.5.11",
    vendor: "dell_os10",
    osVersion: "10.5.5.0",
    macAddress: "00:0A:E9:12:34:56",
    serialNumber: "DEL1092384752",
    lifecycleState: "ContinuousStreamIngestion",
    role: "leaf",
    lastSeenAt: new Date(Date.now() - 3 * 60_000).toISOString(),
    switchOperatingMode: "Smart Fabric",
    switchingMode: "cut-through",
    bootImage: "10.5.5.0.E-active",
    licenseStatus: "active",
    uptime: "14 days, 6 hours",
    hardwareHealth: "ok"
  },
  {
    id: "sw-2",
    hostname: "leaf-02.demo",
    managementIp: "10.5.5.12",
    vendor: "dell_os10",
    osVersion: "10.5.5.0",
    macAddress: "00:0A:E9:12:34:57",
    serialNumber: "DEL1092384753",
    lifecycleState: "ConfigurationDrifted",
    role: "leaf",
    lastSeenAt: new Date(Date.now() - 8 * 60_000).toISOString(),
    switchOperatingMode: "Smart Fabric",
    switchingMode: "cut-through",
    bootImage: "10.5.5.0.E-active",
    licenseStatus: "active",
    uptime: "14 days, 5 hours",
    hardwareHealth: "warning"
  },
  {
    id: "sw-3",
    hostname: "spine-01.demo",
    managementIp: "10.5.5.21",
    vendor: "dell_os10",
    osVersion: "10.5.5.0",
    macAddress: "00:0A:E9:12:34:58",
    serialNumber: "DEL1092384754",
    lifecycleState: "CompliantActive",
    role: "spine",
    lastSeenAt: new Date(Date.now() - 1 * 60_000).toISOString(),
    switchOperatingMode: "Full Switch",
    switchingMode: "store-and-forward",
    bootImage: "10.5.5.0.E-active",
    licenseStatus: "active",
    uptime: "32 days, 1 hour",
    hardwareHealth: "ok"
  },
  {
    id: "sw-4",
    hostname: "leaf-03.demo",
    managementIp: "10.5.5.13",
    vendor: "dell_os10",
    osVersion: "10.5.4.0",
    macAddress: "00:0A:E9:12:34:59",
    serialNumber: "DEL1092384755",
    lifecycleState: "DiscoveredRaw",
    role: "leaf",
    lastSeenAt: new Date(Date.now() - 30 * 60_000).toISOString(),
    switchOperatingMode: "Smart Fabric",
    switchingMode: "cut-through",
    bootImage: "10.5.4.0.E-active",
    licenseStatus: "unlicensed",
    uptime: "0 days, 0 hours",
    hardwareHealth: "unknown"
  },
  {
    id: "sw-5",
    hostname: "spine-02.demo",
    managementIp: "10.5.5.22",
    vendor: "dell_os10",
    osVersion: "10.5.5.0",
    macAddress: "00:0A:E9:12:34:60",
    serialNumber: "DEL1092384756",
    lifecycleState: "SteadyStateAuditing",
    role: "spine",
    lastSeenAt: new Date(Date.now() - 2 * 60_000).toISOString(),
    switchOperatingMode: "Full Switch",
    switchingMode: "store-and-forward",
    bootImage: "10.5.5.0.E-active",
    licenseStatus: "active",
    uptime: "32 days, 1 hour",
    hardwareHealth: "critical"
  }
];

export const MOCK_INTERFACES: Record<string, InterfacePort[]> = {
  "sw-1": [
    {
      id: "if-1", name: "ethernet1/1/1", status: "up", speed: "10G", vlan: 100,
      description: "uplink-to-spine-01", switchportMode: "trunk", portChannelId: "po-1",
      lacpState: "active", stormControlEnabled: true, errdisableReason: null
    },
    {
      id: "if-2", name: "ethernet1/1/2", status: "up", speed: "10G", vlan: 100,
      description: "uplink-to-spine-02", switchportMode: "trunk", portChannelId: "po-1",
      lacpState: "active", stormControlEnabled: true, errdisableReason: null
    },
    {
      id: "if-3", name: "ethernet1/1/3", status: "down", speed: "1G", vlan: 200,
      description: "host-port-04", switchportMode: "access", portChannelId: null,
      lacpState: "none", stormControlEnabled: false, errdisableReason: null
    },
    {
      id: "if-4", name: "ethernet1/1/4", status: "down", speed: "1G", vlan: 200,
      description: "host-port-05", switchportMode: "access", portChannelId: null,
      lacpState: "none", stormControlEnabled: false, errdisableReason: "bpdu-guard"
    }
  ]
};

export const MOCK_SNAPSHOTS: Record<string, ConfigSnapshot[]> = {
  "sw-2": [
    {
      id: "snap-1",
      takenAt: new Date(Date.now() - 2 * 86_400_000).toISOString(),
      isBaseline: true,
      rawConfig: "interface vlan100\n  description corp\n  ip address 10.0.100.1/24\nntp server 192.168.100.1\n"
    },
    {
      id: "snap-2",
      takenAt: new Date(Date.now() - 10 * 60_000).toISOString(),
      isBaseline: false,
      rawConfig: "interface vlan100\n  description corp-renamed\n  ip address 10.0.100.1/24\nntp server 192.168.100.1\n"
    }
  ]
};

export const MOCK_VLT_DOMAINS: Record<string, VltDomain> = {
  "sw-1": {
    id: "vlt-1",
    domainId: 1,
    switchId: "sw-1",
    peerSwitchId: "sw-2",
    peerSwitchHostname: "leaf-02.demo",
    peerLinkStatus: "up",
    iclState: "up",
    peerRoutingEnabled: true,
    vrrpGroups: [{ groupId: 10, vip: "10.0.100.254", state: "master" }]
  },
  "sw-2": {
    id: "vlt-1b",
    domainId: 1,
    switchId: "sw-2",
    peerSwitchId: "sw-1",
    peerSwitchHostname: "leaf-01.demo",
    peerLinkStatus: "up",
    iclState: "down",
    peerRoutingEnabled: true,
    vrrpGroups: [{ groupId: 10, vip: "10.0.100.254", state: "backup" }]
  }
};

export const MOCK_HARDWARE: Record<string, HardwareInventoryItem[]> = {
  "sw-1": [
    { slot: "PSU-1", type: "PSU", status: "ok", detail: "AC 750W, input OK" },
    { slot: "PSU-2", type: "PSU", status: "ok", detail: "AC 750W, input OK" },
    { slot: "Fan-1", type: "Fan", status: "ok", detail: "9800 RPM" },
    { slot: "Fan-2", type: "Fan", status: "ok", detail: "9750 RPM" }
  ],
  "sw-5": [
    { slot: "PSU-1", type: "PSU", status: "critical", detail: "AC input lost" },
    { slot: "PSU-2", type: "PSU", status: "ok", detail: "AC 750W, input OK" },
    { slot: "Fan-1", type: "Fan", status: "warning", detail: "6200 RPM (below threshold)" },
    { slot: "Fan-2", type: "Fan", status: "ok", detail: "9700 RPM" }
  ]
};

export const MOCK_TOPOLOGY: TopologyGraph = {
  nodes: MOCK_SWITCHES.map((s) => ({
    id: s.id,
    hostname: s.hostname,
    lifecycleState: s.lifecycleState,
    role: s.role,
    vltDomainId: MOCK_VLT_DOMAINS[s.id]?.domainId.toString() ?? null
  })),
  edges: [
    { id: "e1", source: "sw-1", target: "sw-3", protocol: "lldp", localInterface: "eth1/1/1", remoteInterface: "eth1/1/1" },
    { id: "e2", source: "sw-1", target: "sw-5", protocol: "lldp", localInterface: "eth1/1/2", remoteInterface: "eth1/1/2" },
    { id: "e3", source: "sw-2", target: "sw-3", protocol: "lldp", localInterface: "eth1/1/1", remoteInterface: "eth1/1/3" },
    { id: "e4", source: "sw-2", target: "sw-5", protocol: "lldp", localInterface: "eth1/1/2", remoteInterface: "eth1/1/4" },
    { id: "e5", source: "sw-1", target: "sw-2", protocol: "vlt-icl", localInterface: "icl-1", remoteInterface: "icl-1" }
  ]
};

export const MOCK_SUBNETS: SubnetSummary[] = [
  { id: "sub-1", cidr: "10.0.100.0/24", vrf: "tenant-blue", total: 254, used: 180, available: 74, utilizationPct: 70.9 },
  { id: "sub-2", cidr: "10.0.200.0/24", vrf: "tenant-blue", total: 254, used: 240, available: 14, utilizationPct: 94.5 },
  { id: "sub-3", cidr: "10.0.10.0/28", vrf: "tenant-green", total: 14, used: 6, available: 8, utilizationPct: 42.9 }
];

export const MOCK_FINDINGS: ComplianceFinding[] = [
  {
    id: "find-1",
    switchHostname: "leaf-02.demo",
    vector: "NTP",
    expected: "192.168.100.1",
    actual: "192.168.1.1",
    severity: "Medium",
    status: "open",
    remediation: "Reapply the base provisioning role to restore the NTP target to 192.168.100.1."
  },
  {
    id: "find-2",
    switchHostname: "leaf-04.demo",
    vector: "AAA",
    expected: "Enabled",
    actual: "Disabled",
    severity: "Critical",
    status: "open",
    remediation: "AAA local management authentication is disabled. Re-run base_provisioning immediately."
  },
  {
    id: "find-3",
    switchHostname: "leaf-02.demo",
    vector: "VLT_PEER_LINK",
    expected: "up",
    actual: "down",
    severity: "Critical",
    status: "open",
    remediation: "VLT ICL is down on leaf-02.demo. Verify physical cabling on the inter-chassis link before any further config changes to avoid a split-brain condition."
  },
  {
    id: "find-4",
    switchHostname: "spine-02.demo",
    vector: "HARDWARE",
    expected: "All PSUs OK",
    actual: "PSU-1 AC input lost",
    severity: "Critical",
    status: "open",
    remediation: "Check power feed and cabling to PSU-1 on spine-02.demo, or replace the PSU if input restoration does not clear the fault."
  }
];

export const MOCK_DASHBOARD: DashboardSummary = {
  totalSwitches: MOCK_SWITCHES.length,
  compliantActive: MOCK_SWITCHES.filter((s) => s.lifecycleState === "CompliantActive").length,
  configurationDrifted: MOCK_SWITCHES.filter((s) => s.lifecycleState === "ConfigurationDrifted").length,
  pendingApprovals: 1,
  lifecycleDistribution: [
    { state: "DiscoveredRaw", count: 1 },
    { state: "CompliantActive", count: 1 },
    { state: "SteadyStateAuditing", count: 1 },
    { state: "ContinuousStreamIngestion", count: 1 },
    { state: "ConfigurationDrifted", count: 1 }
  ],
  complianceTrend: Array.from({ length: 14 }).map((_, i) => ({
    date: new Date(Date.now() - (13 - i) * 86_400_000).toISOString().slice(0, 10),
    score: 78 + Math.round(Math.sin(i / 2) * 6 + i * 0.8)
  }))
};

export const MOCK_APPROVALS: PendingApproval[] = [
  {
    id: "appr-1",
    tenantName: "tenant-blue",
    summary: "Add VLAN 240 to VRF tenant-blue on spine-01.demo",
    targetRole: "spine",
    blastRadius: 6,
    diff:
      "+ interface vlan240\n+   description tenant-blue-overflow\n+   ip address 10.0.240.1/24\n+ vrf member tenant-blue",
    requestedAt: new Date(Date.now() - 25 * 60_000).toISOString()
  }
];

export const MOCK_DIAGNOSTIC_BUNDLES: Record<string, DiagnosticBundle> = {};

