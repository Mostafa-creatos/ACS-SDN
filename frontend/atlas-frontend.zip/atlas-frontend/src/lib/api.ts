import axios from "axios";
import type {
  Switch,
  InterfacePort,
  ConfigSnapshot,
  VltDomain,
  HardwareInventoryItem,
  DiagnosticBundle,
  TopologyGraph
} from "./types";
import {
  MOCK_SWITCHES,
  MOCK_INTERFACES,
  MOCK_SNAPSHOTS,
  MOCK_VLT_DOMAINS,
  MOCK_HARDWARE,
  MOCK_TOPOLOGY
} from "./mockData";

export const api = axios.create({ baseURL: "/api/v5" });

api.interceptors.request.use((config) => {
  const token = localStorage.getItem("atlas_token");
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Demo mode: if USE_MOCK is true (no backend wired up yet), every function
// below resolves with local mock data instead of hitting the network.
// Flip this to false once the FastAPI backend's /api/v5/... routes exist.
const USE_MOCK = true;

function delay<T>(value: T, ms = 250): Promise<T> {
  return new Promise((resolve) => setTimeout(() => resolve(value), ms));
}

export async function fetchSwitches(): Promise<Switch[]> {
  if (USE_MOCK) return delay(MOCK_SWITCHES);
  const { data } = await api.get<Switch[]>("/switches");
  return data;
}

export async function fetchSwitch(id: string): Promise<Switch | undefined> {
  if (USE_MOCK) return delay(MOCK_SWITCHES.find((s) => s.id === id));
  const { data } = await api.get<Switch>(`/switches/${id}`);
  return data;
}

export async function fetchInterfaces(switchId: string): Promise<InterfacePort[]> {
  if (USE_MOCK) return delay(MOCK_INTERFACES[switchId] ?? []);
  const { data } = await api.get<InterfacePort[]>(`/switches/${switchId}/interfaces`);
  return data;
}

export async function fetchSnapshots(switchId: string): Promise<ConfigSnapshot[]> {
  if (USE_MOCK) return delay(MOCK_SNAPSHOTS[switchId] ?? []);
  const { data } = await api.get<ConfigSnapshot[]>(`/switches/${switchId}/snapshots`);
  return data;
}

export async function fetchVltDomain(switchId: string): Promise<VltDomain | null> {
  if (USE_MOCK) return delay(MOCK_VLT_DOMAINS[switchId] ?? null);
  const { data } = await api.get<VltDomain | null>(`/switches/${switchId}/vlt`);
  return data;
}

export async function fetchHardware(switchId: string): Promise<HardwareInventoryItem[]> {
  if (USE_MOCK) return delay(MOCK_HARDWARE[switchId] ?? []);
  const { data } = await api.get<HardwareInventoryItem[]>(`/switches/${switchId}/hardware`);
  return data;
}

export async function fetchTopologyGraph(): Promise<TopologyGraph> {
  if (USE_MOCK) return delay(MOCK_TOPOLOGY);
  const { data } = await api.get<TopologyGraph>("/topology/graph");
  return data;
}

export async function triggerRollback(switchId: string): Promise<{ status: "completed" | "pending_approval" }> {
  if (USE_MOCK) {
    const sw = MOCK_SWITCHES.find((s) => s.id === switchId);
    return delay({ status: sw?.role === "spine" ? "pending_approval" : "completed" }, 600);
  }
  const { data } = await api.post(`/switches/${switchId}/rollback`);
  return data;
}

export async function requestDiagnosticBundle(switchId: string): Promise<DiagnosticBundle> {
  if (USE_MOCK) {
    const pending: DiagnosticBundle = {
      id: `bundle-${switchId}`,
      switchId,
      status: "pending",
      requestedAt: new Date().toISOString(),
      downloadUrl: null
    };
    // simulate the bundle becoming ready after a short delay
    await delay(null, 1200);
    return { ...pending, status: "ready", downloadUrl: "#" };
  }
  const { data } = await api.post<DiagnosticBundle>(`/switches/${switchId}/diagnostics`);
  return data;
}
