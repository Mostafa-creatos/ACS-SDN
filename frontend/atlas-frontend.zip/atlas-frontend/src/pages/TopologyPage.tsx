import { useEffect, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import cytoscape, { type Core } from "cytoscape";
import fcose from "cytoscape-fcose";
import dagre from "cytoscape-dagre";
import { fetchTopologyGraph } from "@/lib/api";
import type { LifecycleState, TopologyNode } from "@/lib/types";

cytoscape.use(fcose);
cytoscape.use(dagre);

const LIFECYCLE_COLORS: Record<LifecycleState, string> = {
  DiscoveredRaw: "#BAC0D8",
  CompliantActive: "#42CCB2",
  SteadyStateAuditing: "#564EBD",
  ContinuousStreamIngestion: "#42CCB2",
  ConfigurationDrifted: "#E26C48"
};

type LayoutOption = "fcose" | "dagre" | "circle" | "grid";

export default function TopologyPage() {
  const containerRef = useRef<HTMLDivElement>(null);
  const cyRef = useRef<Core | null>(null);
  const [layout, setLayout] = useState<LayoutOption>("fcose");
  const [selectedNode, setSelectedNode] = useState<TopologyNode | null>(null);

  const { data: graph } = useQuery({ queryKey: ["topology"], queryFn: fetchTopologyGraph });

  useEffect(() => {
    if (!containerRef.current || !graph) return;

    const cy = cytoscape({
      container: containerRef.current,
      elements: [
        ...graph.nodes.map((n) => ({ data: { id: n.id, label: n.hostname, lifecycleState: n.lifecycleState } })),
        ...graph.edges.map((e) => ({
          data: { id: e.id, source: e.source, target: e.target, protocol: e.protocol }
        }))
      ],
      style: [
        {
          selector: "node",
          style: {
            "background-color": (ele: any) => LIFECYCLE_COLORS[ele.data("lifecycleState") as LifecycleState],
            label: "data(label)",
            color: "#E8EAF6",
            "font-size": 10,
            "text-valign": "bottom",
            "text-margin-y": 6,
            width: 28,
            height: 28,
            "border-width": 2,
            "border-color": (ele: any) => LIFECYCLE_COLORS[ele.data("lifecycleState") as LifecycleState],
            "border-opacity": 0.4
          }
        },
        {
          selector: "edge",
          style: {
            width: (ele: any) => (ele.data("protocol") === "vlt-icl" ? 3 : 1.5),
            "line-color": "#BAC0D8",
            "line-style": (ele: any) => (ele.data("protocol") === "vlt-icl" ? "dashed" : "solid"),
            "curve-style": "bezier"
          }
        }
      ],
      layout: { name: "fcose" }
    });

    cy.on("tap", "node", (evt) => {
      const id = evt.target.id();
      const node = graph.nodes.find((n) => n.id === id) ?? null;
      setSelectedNode(node);
    });

    cyRef.current = cy;
    return () => cy.destroy();
  }, [graph]);

  useEffect(() => {
    if (!cyRef.current) return;
    cyRef.current.layout({ name: layout === "grid" ? "grid" : layout === "circle" ? "circle" : layout }).run();
  }, [layout]);

  return (
    <div className="relative h-full">
      <div className="absolute top-4 left-4 z-10 flex gap-2 bg-white/90 backdrop-blur rounded-md p-2 shadow-card">
        {(["fcose", "dagre", "circle", "grid"] as LayoutOption[]).map((opt) => (
          <button
            key={opt}
            onClick={() => setLayout(opt)}
            className={`px-3 py-1.5 text-xs rounded font-medium ${
              layout === opt ? "bg-atlas-primary text-white" : "text-ink-muted hover:bg-surface-light"
            }`}
          >
            {opt === "fcose" ? "Force-Directed" : opt === "dagre" ? "Hierarchical" : opt === "circle" ? "Circular" : "Grid"}
          </button>
        ))}
      </div>

      <div ref={containerRef} className="h-full w-full" style={{ background: "#14132B" }} />

      {selectedNode && (
        <div className="absolute top-0 right-0 h-full w-72 bg-white shadow-lg p-5 z-10 overflow-y-auto">
          <button className="text-xs text-ink-muted mb-3" onClick={() => setSelectedNode(null)}>
            Close ✕
          </button>
          <h3 className="font-display font-semibold text-lg mb-1">{selectedNode.hostname}</h3>
          <p className="text-sm text-ink-muted mb-4">{selectedNode.role}</p>
          <a href={`/switches/${selectedNode.id}`} className="btn-primary w-full justify-center">
            View Full Detail
          </a>
        </div>
      )}
    </div>
  );
}
