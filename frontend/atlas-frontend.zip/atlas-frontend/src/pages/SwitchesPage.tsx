import { useState } from "react";
import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { Search } from "lucide-react";
import { fetchSwitches } from "@/lib/api";
import { LifecycleStatusPill } from "@/components/StatusPill";
import { HardwareHealthIcon } from "@/components/HealthBadge";
import type { LifecycleState } from "@/lib/types";

function relativeTime(iso: string): string {
  const diffMs = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diffMs / 60_000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  return `${Math.floor(hours / 24)}d ago`;
}

export default function SwitchesPage() {
  const [search, setSearch] = useState("");
  const [lifecycleFilter, setLifecycleFilter] = useState<LifecycleState | "all">("all");

  const { data: switches = [], isLoading } = useQuery({ queryKey: ["switches"], queryFn: fetchSwitches });

  const filtered = switches.filter((s) => {
    const matchesSearch =
      s.hostname.toLowerCase().includes(search.toLowerCase()) ||
      s.managementIp.includes(search) ||
      s.serialNumber.toLowerCase().includes(search.toLowerCase());
    const matchesLifecycle = lifecycleFilter === "all" || s.lifecycleState === lifecycleFilter;
    return matchesSearch && matchesLifecycle;
  });

  return (
    <div className="p-6 space-y-4">
      <h1 className="text-2xl font-display font-semibold text-atlas-ink">Switches</h1>

      <div className="flex items-center gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-ink-muted" />
          <input
            type="text"
            placeholder="Search hostname, IP, or serial..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-sm rounded-md border border-atlas-lavender/50 focus:outline-none focus:ring-2 focus:ring-atlas-violet"
          />
        </div>
        <select
          value={lifecycleFilter}
          onChange={(e) => setLifecycleFilter(e.target.value as LifecycleState | "all")}
          className="text-sm rounded-md border border-atlas-lavender/50 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-atlas-violet"
        >
          <option value="all">All lifecycle states</option>
          <option value="DiscoveredRaw">Discovered</option>
          <option value="CompliantActive">Compliant & Active</option>
          <option value="SteadyStateAuditing">Auditing</option>
          <option value="ContinuousStreamIngestion">Streaming</option>
          <option value="ConfigurationDrifted">Drifted</option>
        </select>
      </div>

      <div className="atlas-card !p-0 overflow-hidden">
        {isLoading ? (
          <p className="p-6 text-sm text-ink-muted">Loading switches...</p>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-ink-muted bg-surface-light border-b border-atlas-lavender/30">
                <th className="py-3 px-4 font-medium">Hostname</th>
                <th className="py-3 px-4 font-medium">Mgmt IP</th>
                <th className="py-3 px-4 font-medium">Vendor</th>
                <th className="py-3 px-4 font-medium">OS Version</th>
                <th className="py-3 px-4 font-medium">Lifecycle State</th>
                <th className="py-3 px-4 font-medium">HW</th>
                <th className="py-3 px-4 font-medium">Last Seen</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((sw) => (
                <tr key={sw.id} className="border-b border-atlas-lavender/15 last:border-0 hover:bg-surface-light">
                  <td className="py-3 px-4">
                    <Link to={`/switches/${sw.id}`} className="font-medium text-atlas-primary hover:underline">
                      {sw.hostname}
                    </Link>
                  </td>
                  <td className="py-3 px-4 text-ink-muted">{sw.managementIp}</td>
                  <td className="py-3 px-4">{sw.vendor}</td>
                  <td className="py-3 px-4">{sw.osVersion}</td>
                  <td className="py-3 px-4">
                    <LifecycleStatusPill state={sw.lifecycleState} />
                  </td>
                  <td className="py-3 px-4">
                    <HardwareHealthIcon status={sw.hardwareHealth} />
                  </td>
                  <td className="py-3 px-4 text-ink-muted">{relativeTime(sw.lastSeenAt)}</td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-ink-muted">
                    No switches match your search/filter.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
