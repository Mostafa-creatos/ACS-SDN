import { useState } from "react";
import { useParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import clsx from "clsx";
import {
  fetchSwitch,
  fetchInterfaces,
  fetchSnapshots,
  fetchVltDomain,
  fetchHardware,
  triggerRollback
} from "@/lib/api";
import { LifecycleStatusPill } from "@/components/StatusPill";
import { HardwareHealthBadge } from "@/components/HealthBadge";
import { FabricVltTab } from "@/components/FabricVltTab";
import { HardwareHealthTab } from "@/components/HardwareHealthTab";
import { DiagnosticBundleButton } from "@/components/DiagnosticBundleButton";
import { RotateCcw, Loader2 } from "lucide-react";

type TabKey = "overview" | "interfaces" | "configuration" | "fabric" | "hardware";

const TABS: { key: TabKey; label: string }[] = [
  { key: "overview", label: "Overview" },
  { key: "interfaces", label: "Interfaces" },
  { key: "configuration", label: "Configuration" },
  { key: "fabric", label: "Fabric & VLT" },
  { key: "hardware", label: "Hardware & Health" }
];

export default function SwitchDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [activeTab, setActiveTab] = useState<TabKey>("overview");
  const [rollbackState, setRollbackState] = useState<"idle" | "loading" | "completed" | "pending_approval">("idle");

  const switchQuery = useQuery({ queryKey: ["switch", id], queryFn: () => fetchSwitch(id!), enabled: !!id });
  const interfacesQuery = useQuery({
    queryKey: ["interfaces", id],
    queryFn: () => fetchInterfaces(id!),
    enabled: !!id && activeTab === "interfaces"
  });
  const snapshotsQuery = useQuery({
    queryKey: ["snapshots", id],
    queryFn: () => fetchSnapshots(id!),
    enabled: !!id && activeTab === "configuration"
  });
  const vltQuery = useQuery({
    queryKey: ["vlt", id],
    queryFn: () => fetchVltDomain(id!),
    enabled: !!id && activeTab === "fabric"
  });
  const hardwareQuery = useQuery({
    queryKey: ["hardware", id],
    queryFn: () => fetchHardware(id!),
    enabled: !!id && activeTab === "hardware"
  });

  if (switchQuery.isLoading) {
    return <div className="p-6 text-ink-muted">Loading switch...</div>;
  }
  if (!switchQuery.data) {
    return <div className="p-6 text-atlas-coral">Switch not found.</div>;
  }

  const sw = switchQuery.data;
  const canRollback = sw.lifecycleState === "ConfigurationDrifted";

  async function handleRollback() {
    setRollbackState("loading");
    const result = await triggerRollback(sw.id);
    setRollbackState(result.status);
  }

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-display font-semibold text-atlas-ink">{sw.hostname}</h1>
          <p className="text-sm text-ink-muted">{sw.managementIp}</p>
        </div>
        <div className="flex items-center gap-3">
          <LifecycleStatusPill state={sw.lifecycleState} />
          <DiagnosticBundleButton switchId={sw.id} />
          <button
            type="button"
            className="btn-danger"
            disabled={!canRollback || rollbackState === "loading"}
            onClick={handleRollback}
          >
            {rollbackState === "loading" ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <RotateCcw className="h-4 w-4" />
            )}
            Trigger Rollback
          </button>
        </div>
      </div>

      {rollbackState === "completed" && (
        <div className="atlas-card border-atlas-teal/40 bg-atlas-teal/5 text-sm text-emerald-800">
          Rollback completed. The switch has returned to Compliant Active with a fresh snapshot recorded.
        </div>
      )}
      {rollbackState === "pending_approval" && (
        <div className="atlas-card border-atlas-coral/40 bg-atlas-coral/5 text-sm text-orange-800">
          This is a spine switch (Impact: 6 devices). The rollback has been queued and requires
          Four-Eyes Approval before it executes -- see Pending Approvals.
        </div>
      )}

      {/* Tab bar */}
      <div className="border-b border-atlas-lavender/30 flex gap-1">
        {TABS.map((tab) => (
          <button
            key={tab.key}
            type="button"
            onClick={() => setActiveTab(tab.key)}
            className={clsx(
              "px-4 py-2 text-sm font-medium border-b-2 -mb-px transition-colors",
              activeTab === tab.key
                ? "border-atlas-primary text-atlas-primary"
                : "border-transparent text-ink-muted hover:text-atlas-ink"
            )}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab content */}
      <div>
        {activeTab === "overview" && (
          <div className="grid grid-cols-2 gap-4">
            <div className="atlas-card space-y-3">
              <h3 className="text-base font-display font-semibold mb-1">Specifications</h3>
              <Spec label="Vendor" value={sw.vendor} />
              <Spec label="OS Version" value={sw.osVersion} />
              <Spec label="Serial Number" value={sw.serialNumber} />
              <Spec label="MAC Address" value={sw.macAddress} />
              <Spec label="Role" value={sw.role === "spine" ? "Spine (high blast radius)" : "Leaf"} />
            </div>
            <div className="atlas-card space-y-3">
              <h3 className="text-base font-display font-semibold mb-1">Operational State</h3>
              <Spec label="Switch Operating Mode" value={sw.switchOperatingMode} />
              <Spec label="Switching Mode" value={sw.switchingMode} />
              <Spec label="Boot Image" value={sw.bootImage} />
              <Spec label="License" value={sw.licenseStatus} />
              <Spec label="Uptime" value={sw.uptime} />
              <div className="flex items-center justify-between pt-1">
                <span className="text-sm text-ink-muted">Hardware Health</span>
                <HardwareHealthBadge status={sw.hardwareHealth} />
              </div>
            </div>
          </div>
        )}

        {activeTab === "interfaces" && (
          <div className="atlas-card">
            {interfacesQuery.isLoading ? (
              <p className="text-sm text-ink-muted">Loading interfaces...</p>
            ) : (
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-left text-ink-muted border-b border-atlas-lavender/30">
                    <th className="py-2 font-medium">Name</th>
                    <th className="py-2 font-medium">Status</th>
                    <th className="py-2 font-medium">Speed</th>
                    <th className="py-2 font-medium">Mode</th>
                    <th className="py-2 font-medium">Port-Channel</th>
                    <th className="py-2 font-medium">VLAN</th>
                    <th className="py-2 font-medium">Description</th>
                  </tr>
                </thead>
                <tbody>
                  {(interfacesQuery.data ?? []).map((iface) => (
                    <tr key={iface.id} className="border-b border-atlas-lavender/15 last:border-0">
                      <td className="py-2 font-medium">{iface.name}</td>
                      <td className="py-2">
                        <span
                          className={clsx(
                            "status-pill",
                            iface.status === "up"
                              ? "bg-atlas-teal/15 text-emerald-800"
                              : iface.errdisableReason
                              ? "bg-atlas-coral/15 text-orange-800"
                              : "bg-slate-100 text-slate-600"
                          )}
                        >
                          {iface.errdisableReason ? `err-disabled (${iface.errdisableReason})` : iface.status}
                        </span>
                      </td>
                      <td className="py-2">{iface.speed}</td>
                      <td className="py-2">{iface.switchportMode}</td>
                      <td className="py-2">{iface.portChannelId ?? "-"}</td>
                      <td className="py-2">{iface.vlan ?? "-"}</td>
                      <td className="py-2 text-ink-muted">{iface.description}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        )}

        {activeTab === "configuration" && (
          <div className="atlas-card">
            {snapshotsQuery.isLoading ? (
              <p className="text-sm text-ink-muted">Loading snapshots...</p>
            ) : (
              <div className="space-y-3">
                {(snapshotsQuery.data ?? []).map((snap) => (
                  <div key={snap.id} className="border border-atlas-lavender/30 rounded-md p-3">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium">
                        {new Date(snap.takenAt).toLocaleString()}
                        {snap.isBaseline && (
                          <span className="ml-2 status-pill bg-atlas-primary/10 text-atlas-primary">baseline</span>
                        )}
                      </span>
                    </div>
                    <pre className="text-xs bg-surface-light rounded p-3 overflow-x-auto font-mono">
                      {snap.rawConfig}
                    </pre>
                  </div>
                ))}
                {(snapshotsQuery.data ?? []).length === 0 && (
                  <p className="text-sm text-ink-muted">No configuration snapshots recorded yet.</p>
                )}
              </div>
            )}
          </div>
        )}

        {activeTab === "fabric" && (
          vltQuery.isLoading ? (
            <p className="text-sm text-ink-muted">Loading fabric state...</p>
          ) : (
            <FabricVltTab vlt={vltQuery.data ?? null} />
          )
        )}

        {activeTab === "hardware" && (
          hardwareQuery.isLoading ? (
            <p className="text-sm text-ink-muted">Loading hardware inventory...</p>
          ) : (
            <HardwareHealthTab items={hardwareQuery.data ?? []} />
          )
        )}
      </div>
    </div>
  );
}

function Spec({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between text-sm">
      <span className="text-ink-muted">{label}</span>
      <span className="font-medium">{value}</span>
    </div>
  );
}
