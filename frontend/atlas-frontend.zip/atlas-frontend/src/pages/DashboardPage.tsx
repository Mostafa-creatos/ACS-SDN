import { useQuery } from "@tanstack/react-query";
import { PieChart, Pie, Cell, LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { Link } from "react-router-dom";
import { MOCK_DASHBOARD } from "@/lib/mockData";
import type { LifecycleState } from "@/lib/types";

const LIFECYCLE_COLORS: Record<LifecycleState, string> = {
  DiscoveredRaw: "#BAC0D8",
  CompliantActive: "#42CCB2",
  SteadyStateAuditing: "#564EBD",
  ContinuousStreamIngestion: "#42CCB2",
  ConfigurationDrifted: "#E26C48"
};

async function fetchDashboard() {
  await new Promise((r) => setTimeout(r, 200));
  return MOCK_DASHBOARD;
}

function MetricCard({ label, value, accent }: { label: string; value: number; accent?: string }) {
  return (
    <div className="atlas-card">
      <p className="text-sm text-ink-muted mb-1">{label}</p>
      <p className="text-3xl font-display font-semibold" style={accent ? { color: accent } : undefined}>
        {value}
      </p>
    </div>
  );
}

export default function DashboardPage() {
  const { data, isLoading } = useQuery({ queryKey: ["dashboard"], queryFn: fetchDashboard });

  if (isLoading || !data) return <div className="p-6 text-ink-muted">Loading dashboard...</div>;

  return (
    <div className="p-6 space-y-6">
      <h1 className="text-2xl font-display font-semibold text-atlas-ink">Dashboard</h1>

      <div className="grid grid-cols-4 gap-4">
        <MetricCard label="Total Switches" value={data.totalSwitches} />
        <MetricCard label="Compliant & Active" value={data.compliantActive} accent="#1C8C77" />
        <MetricCard
          label="Configuration Drifted"
          value={data.configurationDrifted}
          accent={data.configurationDrifted > 0 ? "#E26C48" : undefined}
        />
        <Link to="/approvals">
          <MetricCard label="Pending Approvals" value={data.pendingApprovals} accent="#564EBD" />
        </Link>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="atlas-card">
          <h3 className="text-base font-display font-semibold mb-3">Lifecycle Distribution</h3>
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie data={data.lifecycleDistribution} dataKey="count" nameKey="state" innerRadius={50} outerRadius={80}>
                {data.lifecycleDistribution.map((entry) => (
                  <Cell key={entry.state} fill={LIFECYCLE_COLORS[entry.state]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
        <div className="atlas-card">
          <h3 className="text-base font-display font-semibold mb-3">Compliance Trend (30 days)</h3>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={data.complianceTrend}>
              <XAxis dataKey="date" hide />
              <YAxis domain={[0, 100]} width={30} />
              <Tooltip />
              <Line type="monotone" dataKey="score" stroke="#42CCB2" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="flex gap-3">
        <Link to="/compliance" className="btn-primary">
          Run Compliance Audit
        </Link>
        <Link to="/approvals" className="btn-secondary">
          View Pending Approvals
        </Link>
      </div>
    </div>
  );
}
