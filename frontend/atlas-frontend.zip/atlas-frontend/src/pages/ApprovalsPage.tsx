import { useState } from "react";
import { MOCK_APPROVALS } from "@/lib/mockData";

export default function ApprovalsPage() {
  const [approvals, setApprovals] = useState(MOCK_APPROVALS);
  const [confirmingId, setConfirmingId] = useState<string | null>(null);

  function approve(id: string) {
    setApprovals((prev) => prev.filter((a) => a.id !== id));
    setConfirmingId(null);
  }

  return (
    <div className="p-6 space-y-4">
      <h1 className="text-2xl font-display font-semibold text-atlas-ink">Pending Approvals</h1>

      {approvals.length === 0 && (
        <div className="atlas-card text-center py-12">
          <p className="text-ink-muted">No changes are waiting for approval.</p>
        </div>
      )}

      <div className="space-y-4">
        {approvals.map((a) => (
          <div key={a.id} className="atlas-card border-atlas-coral/30">
            <div className="flex items-start justify-between mb-3">
              <div>
                <p className="text-sm text-ink-muted mb-1">{a.tenantName}</p>
                <p className="font-medium">{a.summary}</p>
              </div>
              <span className="status-pill bg-atlas-coral/15 text-orange-800 font-semibold">
                Spine · Impact: {a.blastRadius} devices
              </span>
            </div>

            <pre className="text-xs bg-surface-light rounded p-3 overflow-x-auto font-mono mb-4">
              {a.diff.split("\n").map((line, i) => (
                <div key={i} className={line.startsWith("+") ? "text-emerald-700" : line.startsWith("-") ? "text-orange-700" : ""}>
                  {line}
                </div>
              ))}
            </pre>

            {confirmingId === a.id ? (
              <div className="bg-atlas-coral/5 border border-atlas-coral/30 rounded-md p-3 space-y-3">
                <p className="text-sm text-orange-800">
                  You are approving a change affecting {a.blastRadius} devices. This cannot be undone automatically.
                </p>
                <div className="flex gap-2">
                  <button className="btn-danger" onClick={() => approve(a.id)}>
                    Confirm Approve
                  </button>
                  <button className="btn-secondary" onClick={() => setConfirmingId(null)}>
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex gap-2">
                <button className="btn-primary" onClick={() => setConfirmingId(a.id)}>
                  Approve
                </button>
                <button className="btn-secondary">Reject</button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
