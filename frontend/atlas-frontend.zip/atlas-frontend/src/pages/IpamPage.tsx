import { useState } from "react";
import { Search } from "lucide-react";
import { MOCK_SUBNETS } from "@/lib/mockData";
import type { IpSearchResult } from "@/lib/types";

export default function IpamPage() {
  const [ipQuery, setIpQuery] = useState("");
  const [result, setResult] = useState<IpSearchResult | null | "not_found">(null);

  function handleSearch() {
    if (!ipQuery) return;
    if (ipQuery === "10.0.100.50") {
      setResult({
        ipAddress: ipQuery,
        switchHostname: "leaf-01.demo",
        interfaceName: "ethernet1/1/3",
        vlan: 200,
        vrf: "tenant-blue",
        lastSeenAt: new Date().toISOString()
      });
    } else {
      setResult("not_found");
    }
  }

  return (
    <div className="p-6 space-y-6">
      <h1 className="text-2xl font-display font-semibold text-atlas-ink">IP Management</h1>

      <div className="atlas-card">
        <h3 className="text-base font-display font-semibold mb-3">IP Finder</h3>
        <div className="flex gap-2">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-ink-muted" />
            <input
              type="text"
              placeholder="Search an IP address (try 10.0.100.50)"
              value={ipQuery}
              onChange={(e) => setIpQuery(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSearch()}
              className="w-full pl-9 pr-3 py-2 text-sm rounded-md border border-atlas-lavender/50 focus:outline-none focus:ring-2 focus:ring-atlas-violet"
            />
          </div>
          <button className="btn-primary" onClick={handleSearch}>
            Search
          </button>
        </div>
        {result === "not_found" && (
          <p className="mt-3 text-sm text-ink-muted">No record found for this address.</p>
        )}
        {result && result !== "not_found" && (
          <div className="mt-3 grid grid-cols-4 gap-4 text-sm border-t border-atlas-lavender/30 pt-3">
            <div><p className="text-ink-muted">Switch</p><p className="font-medium">{result.switchHostname}</p></div>
            <div><p className="text-ink-muted">Interface</p><p className="font-medium">{result.interfaceName}</p></div>
            <div><p className="text-ink-muted">VLAN / VRF</p><p className="font-medium">{result.vlan} / {result.vrf}</p></div>
            <div><p className="text-ink-muted">Last Seen</p><p className="font-medium">just now</p></div>
          </div>
        )}
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div className="atlas-card"><p className="text-sm text-ink-muted mb-1">Total IPs</p><p className="text-3xl font-display font-semibold">522</p></div>
        <div className="atlas-card"><p className="text-sm text-ink-muted mb-1">Used</p><p className="text-3xl font-display font-semibold">426</p></div>
        <div className="atlas-card"><p className="text-sm text-ink-muted mb-1">Available</p><p className="text-3xl font-display font-semibold">96</p></div>
      </div>

      <div className="atlas-card !p-0 overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-ink-muted bg-surface-light border-b border-atlas-lavender/30">
              <th className="py-3 px-4 font-medium">Network</th>
              <th className="py-3 px-4 font-medium">VRF</th>
              <th className="py-3 px-4 font-medium">Used / Total</th>
              <th className="py-3 px-4 font-medium">Utilization</th>
            </tr>
          </thead>
          <tbody>
            {MOCK_SUBNETS.map((s) => (
              <tr key={s.id} className="border-b border-atlas-lavender/15 last:border-0">
                <td className="py-3 px-4 font-medium">{s.cidr}</td>
                <td className="py-3 px-4">{s.vrf}</td>
                <td className="py-3 px-4">{s.used} / {s.total}</td>
                <td className="py-3 px-4">
                  <div className="w-40 h-2 rounded-full bg-slate-100 overflow-hidden">
                    <div
                      className="h-full rounded-full"
                      style={{
                        width: `${s.utilizationPct}%`,
                        backgroundColor: s.utilizationPct >= 90 ? "#E26C48" : "#42CCB2"
                      }}
                    />
                  </div>
                  <span className="text-xs text-ink-muted">{s.utilizationPct.toFixed(1)}%</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
