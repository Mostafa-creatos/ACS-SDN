import { MOCK_FINDINGS } from "@/lib/mockData";
import { SeverityPill } from "@/components/StatusPill";

const SCORE = 84;

export default function CompliancePage() {
  const gaugeColor = SCORE >= 80 ? "#42CCB2" : "#E26C48";

  return (
    <div className="p-6 space-y-6">
      <h1 className="text-2xl font-display font-semibold text-atlas-ink">Compliance</h1>

      <div className="grid grid-cols-4 gap-4 items-stretch">
        <div className="atlas-card flex flex-col items-center justify-center">
          <p className="text-sm text-ink-muted mb-2">Overall Score</p>
          <p className="text-4xl font-display font-bold" style={{ color: gaugeColor }}>
            {SCORE}%
          </p>
        </div>
        <div className="atlas-card flex flex-col justify-center">
          <p className="text-sm text-ink-muted mb-1">Compliant Switches</p>
          <p className="text-2xl font-display font-semibold text-emerald-700">3</p>
        </div>
        <div className="atlas-card flex flex-col justify-center">
          <p className="text-sm text-ink-muted mb-1">Non-Compliant</p>
          <p className="text-2xl font-display font-semibold text-orange-700">2</p>
        </div>
        <div className="atlas-card flex flex-col justify-center">
          <p className="text-sm text-ink-muted mb-1">Critical Violations</p>
          <p className="text-2xl font-display font-semibold" style={{ color: "#E26C48" }}>
            {MOCK_FINDINGS.filter((f) => f.severity === "Critical").length}
          </p>
        </div>
      </div>

      <div className="flex justify-end">
        <button className="btn-primary">Run Audit</button>
      </div>

      <div className="atlas-card !p-0 overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-ink-muted bg-surface-light border-b border-atlas-lavender/30">
              <th className="py-3 px-4 font-medium">Switch</th>
              <th className="py-3 px-4 font-medium">Vector</th>
              <th className="py-3 px-4 font-medium">Expected</th>
              <th className="py-3 px-4 font-medium">Actual</th>
              <th className="py-3 px-4 font-medium">Severity</th>
              <th className="py-3 px-4 font-medium">Remediation</th>
            </tr>
          </thead>
          <tbody>
            {MOCK_FINDINGS.map((f) => (
              <tr key={f.id} className="border-b border-atlas-lavender/15 last:border-0 align-top">
                <td className="py-3 px-4 font-medium">{f.switchHostname}</td>
                <td className="py-3 px-4">{f.vector}</td>
                <td className="py-3 px-4 text-ink-muted">{f.expected}</td>
                <td className="py-3 px-4 text-ink-muted">{f.actual}</td>
                <td className="py-3 px-4">
                  <SeverityPill severity={f.severity} />
                </td>
                <td className="py-3 px-4 text-ink-muted max-w-xs">{f.remediation}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
