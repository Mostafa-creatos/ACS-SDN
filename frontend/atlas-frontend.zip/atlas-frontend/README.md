# Atlas Cloud SDN Controller — Frontend

React + Vite + TypeScript + Tailwind operator console, styled per the
Frontend Description doc (NacTrack structure + Atlas Cloud Services brand).

## Run locally

```bash
npm install
npm run dev
```

Opens at http://localhost:5173. Runs fully standalone against mock data
(`USE_MOCK = true` in `src/lib/api.ts`) — no backend required to explore the UI.

## Wiring up the real backend

In `src/lib/api.ts`, flip `USE_MOCK` to `false`. The Vite dev server proxies
`/api/*` to `http://localhost:8000` (see `vite.config.ts`) where the FastAPI
backend from the Enterprise SDN Controller Implementation Plan is expected
to run, exposing routes under `/api/v5/...`.

## Structure

- `src/components/` — shared UI: StatusPill, HealthBadge, FabricVltTab,
  HardwareHealthTab, DiagnosticBundleButton
- `src/pages/` — one file per route (Dashboard, Switches, SwitchDetail,
  Topology, IPAM, Compliance, Approvals)
- `src/lib/types.ts` — all shared TypeScript types, including the
  Dell OS10-specific additions (VLT, hardware inventory, diagnostics)
- `src/lib/mockData.ts` — demo data used when `USE_MOCK` is true
- `src/lib/api.ts` — single API client; every page goes through this,
  never calls axios directly

## Notes

- Switch Detail page has 5 tabs: Overview, Interfaces, Configuration,
  Fabric & VLT, Hardware & Health — per the Dell OS10 data-mapping discussion.
- Topology renders VLT inter-chassis links as a distinct dashed edge style.
- Pending Approvals requires an explicit confirmation step before Approve fires.
